# aguaclara_tutorial
This repository is for all team members to find information and tutorials about useful tools like Python, Atom, Hydrogen, GitHub, ProCoDA and report writing.
